from django.apps import AppConfig


class DjangoUwsgiConfig(AppConfig):
    name = 'django_uwsgi'
    label = 'django_uwsgi'
    verbose_name = 'uWSGI for Django'
