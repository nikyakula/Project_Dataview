
default_app_config = 'django_uwsgi.emperor.apps.EmperorConfig'
