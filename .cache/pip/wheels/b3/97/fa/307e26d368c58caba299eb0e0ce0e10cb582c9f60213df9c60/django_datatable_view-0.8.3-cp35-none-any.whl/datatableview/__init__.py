# -*- encoding: utf-8 -*-

__name__ = 'datatableview'
__author__ = 'Tim Valenta'
__version_info__ = (0, 8, 3)
__version__ = '.'.join(map(str, __version_info__))
__date__ = '2013/11/14 2:00:00 PM'
__credits__ = ['Tim Valenta', 'Steven Klass']
__license__ = 'See the file LICENSE.txt for licensing information.'
