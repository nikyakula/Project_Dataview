# -*- encoding: utf-8 -*-

# Required for Django to recognize this app
